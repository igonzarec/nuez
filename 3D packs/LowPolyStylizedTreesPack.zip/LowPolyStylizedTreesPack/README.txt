LOW POLY STYLIZED TREES PACK
============================

50 stylized low poly trees with flat-shaded facets - broadleaf, autumn & blossom, conifers,
bare & dead trees and tropical / exotic species - all textured with ONE shared color palette.

CONTENTS
--------
OBJ/      one .obj + .mtl per tree, plus stylized_trees_palette.png
FBX/      one .fbx per tree (Unity / Unreal ready), plus stylized_trees_palette.png
GLB/      stylized_trees_pack.glb - all 50 trees in a single file, laid out in 5 rows (one per category),
          texture embedded (Godot, web, Roblox)
Texture/  stylized_trees_palette.png (512x512, 8x8 swatches) + palette_reference.png (swatch names)
Preview/  cover and showcase images

Total: 17750 triangles (76-1028 per tree).

ONE TEXTURE FOR EVERYTHING
--------------------------
Every tree uses the same material and the same 512x512 palette texture. Each face is mapped to the
center of a flat color swatch (with padding, so mipmaps never bleed):
- all 50 trees can share one material and be batched together;
- foliage uses 3 tones per color (dark / mid / light) for a soft stylized gradient;
- recolor in seconds: repaint the "green" swatches and every green canopy changes, turn "orange" into
  any autumn color you like, etc. palette_reference.png shows the name of each swatch.
Tip: set the texture filter to Point / Nearest for perfectly crisp colors (Bilinear also works).

SCALE, PIVOT AND ORIENTATION
----------------------------
- Real-world size in meters (1 unit = 1 m): from a 2.4 m sapling to an 18 m sequoia.
- The pivot (origin) of every tree is at the center of the trunk base, on the ground (z = 0).
- Up is +Z in Blender, +Y in the exported OBJ/FBX/GLB files.
- Flat shading (hard edges) for the classic faceted low poly look.

TREES
-----
File                  Category             Tris   Height
oak_tree              Broadleaf              214     7.5 m
oak_tree_large        Broadleaf              306    10.0 m
round_tree            Broadleaf              168     6.0 m
round_tree_small      Broadleaf               76     3.6 m
maple_tree            Broadleaf              260     8.0 m
elm_tree              Broadleaf              286    10.0 m
birch_tree            Broadleaf              374     8.5 m
poplar_tree           Broadleaf              266    11.0 m
cypress_tree          Broadleaf              116    10.0 m
willow_tree           Broadleaf              494     7.0 m
apple_tree            Broadleaf              494     4.8 m
orange_tree           Broadleaf              408     4.0 m
young_tree            Broadleaf              320     3.0 m
slender_tree          Broadleaf              122     9.0 m
autumn_oak            Autumn & Blossom       214     7.5 m
autumn_maple          Autumn & Blossom       260     7.5 m
autumn_birch          Autumn & Blossom       374     8.5 m
aspen_tree            Autumn & Blossom       278     7.0 m
autumn_round_tree     Autumn & Blossom       122     5.0 m
autumn_beech          Autumn & Blossom       286     8.0 m
cherry_blossom        Autumn & Blossom       286     5.5 m
jacaranda_tree        Autumn & Blossom       286     7.0 m
pine_tree             Conifers               184     8.0 m
pine_tree_tall        Conifers               248    12.0 m
pine_tree_small       Conifers               152     4.5 m
spruce_tree           Conifers               280    11.0 m
fir_tree              Conifers               216     8.0 m
blue_spruce           Conifers               248     9.0 m
snowy_pine            Conifers               312     8.0 m
snowy_spruce          Conifers               440    10.0 m
cone_tree             Conifers                96     5.5 m
larch_tree            Conifers               216     9.0 m
sequoia_tree          Conifers               248    18.0 m
dead_pine             Conifers               584     8.0 m
dead_tree             Bare & Dead            594     6.0 m
dead_tree_large       Bare & Dead           1028     9.0 m
bare_tree             Bare & Dead            632     7.0 m
dead_birch            Bare & Dead            568     7.0 m
burnt_tree            Bare & Dead            416     6.0 m
sapling               Bare & Dead            136     2.4 m
spooky_tree           Bare & Dead            570     6.0 m
broken_tree           Bare & Dead            234     4.0 m
palm_tree             Tropical & Exotic      428     9.0 m
coconut_palm          Tropical & Exotic      546    10.0 m
acacia_tree           Tropical & Exotic      260     6.0 m
baobab_tree           Tropical & Exotic      782     8.0 m
joshua_tree           Tropical & Exotic      844     5.0 m
olive_tree            Tropical & Exotic      396     5.0 m
eucalyptus_tree       Tropical & Exotic      716    13.0 m
jungle_tree           Tropical & Exotic      366    14.0 m

HOW TO USE
----------
- Keep each model in the same folder as stylized_trees_palette.png: the .mtl / .fbx files reference it by file name.
- Unity: drag the FBX folder into Assets. If the material appears white, assign stylized_trees_palette.png as Base Map.
  Create one material and use it on all trees.
- Unreal: import the .fbx files and plug stylized_trees_palette.png into the Base Color of a single shared material.
- Godot: import GLB/stylized_trees_pack.glb or the individual .obj files.
- Blender: File > Import > Wavefront (.obj), FBX or glTF.
- Roblox: import the .obj (or .fbx) as a MeshPart and set its TextureID to the uploaded stylized_trees_palette.png.

LICENSE
-------
CC0 1.0 Universal (Public Domain). Free for personal and commercial use, no attribution required.
